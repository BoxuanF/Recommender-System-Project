import numpy as np
from sklearn.impute import KNNImputer
from utils import *
from matplotlib import pyplot as plt


def knn_impute_by_user(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    student similarity. Return the accuracy on valid_data.

    See https://scikit-learn.org/stable/modules/generated/sklearn.
    impute.KNNImputer.html for details.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    nbrs = KNNImputer(n_neighbors=k)
    # We use NaN-Euclidean distance measure.
    mat = nbrs.fit_transform(matrix)
    acc = sparse_matrix_evaluate(valid_data, mat)
    print("Validation Accuracy: {}".format(acc))
    return acc


def knn_impute_by_item(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    question similarity. Return the accuracy on valid_data.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    #####################################################################
    # Implement the function as described in the docstring.             #
    #####################################################################
    nbrs = KNNImputer(n_neighbors=k)
    transposed_matrix = np.transpose(matrix)
    mat = nbrs.fit_transform(transposed_matrix)
    transposed_mat = np.transpose(mat)
    acc = sparse_matrix_evaluate(valid_data, transposed_mat)
    print("Validation Accuracy: {}".format(acc))
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return acc


def main():
    sparse_matrix = load_train_sparse("../data").toarray()
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    print("Sparse matrix:")
    print(sparse_matrix)
    print("Shape of sparse matrix:")
    print(sparse_matrix.shape)

    #####################################################################
    # Compute the validation accuracy for each k. Then pick k* with     #
    # the best performance and report the test accuracy with the        #
    # chosen k*.                                                        #
    #####################################################################
    # 1(a)
    # User-based collaborative filtering
    k_values = [1, 6, 11, 16, 21, 26]
    valid_acc = []
    best_val_acc = 0
    best_k = 0

    for k in k_values:
        acc = knn_impute_by_user(sparse_matrix, val_data, k)
        valid_acc.append(acc)
        if acc > best_val_acc:
            best_val_acc = acc
            best_k = k

    # Plot the validation accuracy as a function of k
    plt.title("Validatation Accuracy for user-based collaborative filtering")
    plt.plot(k_values, valid_acc)
    plt.xlabel("K")
    plt.ylabel("Validatation Accuracy")
    plt.show()

    test_acc = knn_impute_by_user(sparse_matrix, test_data, best_k)
    print("Test Accuracy with k = {}: {}".format(best_k, test_acc))
    # The value of K with the best performance is 11.
    # Test Accuracy with k = 11: 0.6841659610499576

    # 1(b)
    # The underlying assumption on item-based collaborative filtering:
    # If question A is answered correctly by one specific student, and answered
    # incorrectly by the other students the same as question B, the correctness
    # of question A answered by the specific student matches that of question B.

    # 1(c)
    # Item-based collaborative filtering
    k_values = [1, 6, 11, 16, 21, 26]
    valid_acc = []
    best_val_acc = 0
    best_k = 0

    for k in k_values:
        acc = knn_impute_by_item(sparse_matrix, val_data, k)
        valid_acc.append(acc)
        if acc > best_val_acc:
            best_val_acc = acc
            best_k = k

    # Plot the validation accuracy as a function of k
    plt.title("Validatation Accuracy for item-based collaborative filtering")
    plt.plot(k_values, valid_acc)
    plt.xlabel("K")
    plt.ylabel("Validatation Accuracy")
    plt.show()

    test_acc = knn_impute_by_item(sparse_matrix, test_data, best_k)
    print("Test Accuracy with k = {}: {}".format(best_k, test_acc))
    # The value of K with the best performance is 21.
    # Test Accuracy with k = 21: 0.6816257408975445

    # 1(d)
    # User-based collaborative filtering is better.
    # Because it has a higher test accuracy.

    # 1(e)
    # Two potential limitations of kNN:
    # 1. It can't make predictions for a student who has not answered any
    # question or a question which has not been answered by any student because
    # in this case we don't know which data points are the k nearest neighbors.
    # 2. It is computationally intensive because kNN must compute the distances
    # from a specific data point to all other ones to find the k nearest
    # neighbors for each prediction when the training set is very large.
    # 3. If the numbers of students and questions are very large, all data
    # points are far away from each other in an extremely high-dimensional space.
    # Then the closest point is not very predictive.
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


if __name__ == "__main__":
    main()
