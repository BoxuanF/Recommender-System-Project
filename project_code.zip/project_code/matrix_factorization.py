from matplotlib import pyplot as plt
from utils import *
from scipy.linalg import sqrtm
import numpy as np


def svd_reconstruct(matrix, k):
    """ Given the matrix, perform singular value decomposition
    to reconstruct the matrix.

    :param matrix: 2D sparse matrix
    :param k: int
    :return: 2D matrix
    """
    # First, you need to fill in the missing values (NaN) to perform SVD.
    # Fill in the missing values using the average on the current item.
    # Note that there are many options to do fill in the
    # missing values (e.g. fill with 0).
    new_matrix = matrix.copy()
    mask = np.isnan(new_matrix)
    masked_matrix = np.ma.masked_array(new_matrix, mask)
    item_means = np.mean(masked_matrix, axis=0)
    new_matrix = masked_matrix.filled(item_means)

    # Next, compute the average and subtract it.
    item_means = np.mean(new_matrix, axis=0)
    mu = np.tile(item_means, (new_matrix.shape[0], 1))
    new_matrix = new_matrix - mu

    # Perform SVD.
    Q, s, Ut = np.linalg.svd(new_matrix, full_matrices=False)
    s = np.diag(s)

    # Choose top k eigenvalues.
    s = s[0:k, 0:k]
    Q = Q[:, 0:k]
    Ut = Ut[0:k, :]
    s_root = sqrtm(s)

    # Reconstruct the matrix.
    reconst_matrix = np.dot(np.dot(Q, s_root), np.dot(s_root, Ut))
    reconst_matrix = reconst_matrix + mu
    return np.array(reconst_matrix)


def squared_error_loss(data, u, z):
    """ Return the squared-error-loss given the data.
    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param u: 2D matrix
    :param z: 2D matrix
    :return: float
    """
    loss = 0
    for i, q in enumerate(data["question_id"]):
        loss += (data["is_correct"][i]
                 - np.sum(u[data["user_id"][i]] * z[q])) ** 2.
    return 0.5 * loss


def update_u_z(train_data, lr, u, z):
    """ Return the updated U and Z after applying
    stochastic gradient descent for matrix completion.

    :param train_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param u: 2D matrix
    :param z: 2D matrix
    :return: (u, z)
    """
    #####################################################################
    # Implement the function as described in the docstring.             #
    #####################################################################
    # Randomly select a pair (user_id, question_id).
    i = np.random.choice(len(train_data["question_id"]), 1)[0]

    c = train_data["is_correct"][i]
    n = train_data["user_id"][i]
    q = train_data["question_id"][i]

    # Calculate the error for the selected pair.
    error = c - np.dot(u[n], z[q])

    # Calculate the gradient for user features u[n].
    grad_u = -error * z[q]

    # Calculate the gradient for item features z[q].
    grad_z = -error * u[n]

    # Update the user features u[n].
    u[n] = u[n] - lr * grad_u

    # Update the item features z[q].
    z[q] = z[q] - lr * grad_z
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return u, z


def als(train_data, val_data, k, lr, num_iteration):
    """ Performs ALS algorithm, here we use the iterative solution - SGD
    rather than the direct solution.

    :param train_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :param lr: float
    :param num_iteration: int
    :return: 2D reconstructed Matrix.
    """
    # Initialize u and z
    u = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["user_id"])), k))
    z = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["question_id"])), k))

    # for plotting purpose, initiallize the sqred error loss values
    train_sqr_err_l = []
    val_sqr_err_l = []

    for itr in range(num_iteration):
        # Loop through each observation in the train data
        for i in range(len(train_data["user_id"])):
            u, z = update_u_z(train_data, lr, u, z)

        tsel = squared_error_loss(train_data, u, z)
        vsel = squared_error_loss(val_data, u, z)
        train_sqr_err_l.append(tsel)
        val_sqr_err_l.append(vsel)

    # Reconstruct the matrix
    mat = np.dot(u, np.transpose(z))

    return mat, train_sqr_err_l, val_sqr_err_l


def als_for_hyper(train_data, k, lr, num_iteration):
    """ Performs ALS algorithm, used to tune the hyperparameters.

    :param train_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :param lr: float
    :param num_iteration: int
    :return: 2D reconstructed Matrix.
    """
    # Initialize u and z
    u = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["user_id"])), k))
    z = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["question_id"])), k))

    for itr in range(num_iteration):
        # Loop through each observation in the train data
        for i in range(len(train_data["user_id"])):
            u, z = update_u_z(train_data, lr, u, z)

    # Reconstruct the matrix
    mat = np.dot(u, np.transpose(z))
    return mat


def main():
    train_matrix = load_train_sparse("../data").toarray()
    train_data = load_train_csv("../data")
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    #####################################################################
    # (SVD) Try out at least 5 different k and select the best k        #
    # using the validation set.                                         #
    #####################################################################
    # 3(i)(a)
    # Run SVD with at least 5 different k values
    k_values = [1, 9, 15, 18, 25, 30]
    valid_acc = []

    for k in k_values:
        svd = svd_reconstruct(train_matrix, k=k)
        acc = sparse_matrix_evaluate(val_data, svd)
        print("Validation Accuracy: {}".format(acc))
        valid_acc.append(acc)

    print("----------------------------------------------------------")
    # Based on the validation accuracy, the best k is 9

    # Report the validation and test accuracies
    print("Validation Accuracy for k = 9: {}".format(valid_acc[1]))
    # Validation Accuracy for k = 9: 0.6613039796782387

    test_acc = sparse_matrix_evaluate(test_data, svd_reconstruct(train_matrix,
                                                                 k=9))
    print("Test Accuracy for k = 9: {}".format(test_acc))
    # Test Accuracy for k = 9: 0.6587637595258256

    print("----------------------------------------------------------")
    # 3(i)(b)
    # One limitation of SVD for this task:
    # The methodology we used here for filling the missing entries before
    # implementing SVD is that we take the mean of observed entries for every
    # column(meaning that we are considering the probability that question j
    # will be answered correct), and fill in the missing entries using this
    # probability. However, it didn't consider the ability level for different
    # students so that the filling entries will be biased.
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    #####################################################################
    # (ALS) Try out at least 5 different k and select the best k        #
    # using the validation set.                                         #
    #####################################################################
    # 3(i)(d)
    # Tune k, the learning rate, and the number of iterations
    # Warning: It takes a long time!
    num_iter_values = [5, 10, 15]
    k_values = [2, 5, 12, 18, 25] # Try at least 5 different k values
    lr_values = [0.015, 0.02, 0.025]
    max_valid_acc = 0
    best_combination = (0, 0, 0)
    np.random.seed(2)

    for num_iter in num_iter_values:
        for k in k_values:
            for lr in lr_values:
                mat = als_for_hyper(train_data, k, lr, num_iter)
                acc = sparse_matrix_evaluate(val_data, mat)
                if acc > max_valid_acc:
                    max_valid_acc = acc
                    best_combination = num_iter, k, lr

    print("The best combination of num_iter, k and lr: "
          + str(best_combination[0]) + ", " + str(best_combination[1]) + \
          " and " + str(best_combination[2]))
    print("The validation accuracy with the best combination: " +
          str(max_valid_acc))
    # The best combination of num_iter, k and lr: 10, 2 and 0.02
    # The validation accuracy with the best combination: 0.7061812023708721
    print("----------------------------------------------------------")
    # The hyperparameters that we select
    k = 2
    lr = 0.02
    num_iter = 10
    mat, train_sqr_err_l, val_sqr_err_l = als(train_data, val_data, k, lr,
                                              num_iter)

    # 3(i)(e)
    # Plot the training and validation squared-error losses as a function of
    # iteration
    plt.plot(train_sqr_err_l, label='Training Squared Error Loss')
    plt.plot(val_sqr_err_l, label='Validation Squared Error Loss')
    plt.xlabel('Iteration')
    plt.ylabel('Squared Error Loss')
    plt.title('Training and Validation Squared Error Loss')
    plt.legend()
    plt.show()

    print("----------------------------------------------------------")
    # Report the validation accuracy and test accuracies
    acc = sparse_matrix_evaluate(val_data, mat)
    acc_t = sparse_matrix_evaluate(test_data, mat)
    print("Validation Accuracy for the final model: {}".format(acc))
    # Validation Accuracy for the final model: 0.7071690657634773
    print("Test Accuracy for the final model: {}".format(acc_t))
    # Test Accuracy for the final model: 0.698278295230031
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


if __name__ == "__main__":
    main()
