from matplotlib import pyplot as plt
from utils import *
from scipy.linalg import sqrtm
import numpy as np


def svd_reconstruct(matrix, k):
    """ Given the matrix, perform singular value decomposition
    to reconstruct the matrix.

    :param matrix: 2D sparse matrix
    :param k: int
    :return: 2D matrix
    """
    # First, you need to fill in the missing values (NaN) to perform SVD.
    # Fill in the missing values using the average on the current item.
    # Note that there are many options to do fill in the
    # missing values (e.g. fill with 0).
    new_matrix = matrix.copy()
    mask = np.isnan(new_matrix)
    masked_matrix = np.ma.masked_array(new_matrix, mask)
    item_means = np.mean(masked_matrix, axis=0)
    new_matrix = masked_matrix.filled(item_means)

    # Next, compute the average and subtract it.
    item_means = np.mean(new_matrix, axis=0)
    mu = np.tile(item_means, (new_matrix.shape[0], 1))
    new_matrix = new_matrix - mu

    # Perform SVD.
    Q, s, Ut = np.linalg.svd(new_matrix, full_matrices=False)
    s = np.diag(s)

    # Choose top k eigenvalues.
    s = s[0:k, 0:k]
    Q = Q[:, 0:k]
    Ut = Ut[0:k, :]
    s_root = sqrtm(s)

    # Reconstruct the matrix.
    reconst_matrix = np.dot(np.dot(Q, s_root), np.dot(s_root, Ut))
    reconst_matrix = reconst_matrix + mu
    return np.array(reconst_matrix)


def modified_svd_reconstruct(matrix, k):
    """ Modified version of svd_reconstruct, which fill in the missing entries
    with (column mean + row mean) / 2.

    :param matrix: 2D sparse matrix
    :param k: int
    :return: 2D matrix
    """
    # First, calculate each column mean and each row mean.
    new_matrix = matrix.copy()
    mask = np.isnan(new_matrix)
    masked_matrix = np.ma.masked_array(new_matrix, mask)

    item_means_col = np.mean(masked_matrix, axis=0)
    item_means_row = np.mean(masked_matrix, axis=1)

    item_means = np.zeros([542, 1774])

    # Then fill in the missing entries with (column mean + row mean) / 2.
    for i in range(len(item_means_row)):
        for j in range(len(item_means_col)):
            item_means[i, j] = (item_means_row[i] + item_means_col[j]) / 2

    new_matrix = masked_matrix.filled(item_means)

    # Next, compute the average and subtract it.
    item_means = np.mean(new_matrix, axis=0)
    mu = np.tile(item_means, (new_matrix.shape[0], 1))
    new_matrix = new_matrix - mu

    # Perform SVD.
    Q, s, Ut = np.linalg.svd(new_matrix, full_matrices=False)
    s = np.diag(s)

    # Choose top k eigenvalues.
    s = s[0:k, 0:k]
    Q = Q[:, 0:k]
    Ut = Ut[0:k, :]
    s_root = sqrtm(s)

    # Reconstruct the matrix.
    reconst_matrix = np.dot(np.dot(Q, s_root), np.dot(s_root, Ut))
    reconst_matrix = reconst_matrix + mu
    return np.array(reconst_matrix)


def main():
    train_matrix = load_train_sparse("../data").toarray()
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    origin_valid_acc = []
    modified_valid_acc = []
    origin_best_k = 0
    modified_best_k = 0
    origin_max_val_acc = 0
    modified_max_val_acc = 0

    k_values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    for k in k_values:
        origin_svd = svd_reconstruct(train_matrix, k=k)
        origin_acc = sparse_matrix_evaluate(val_data, origin_svd)
        origin_valid_acc.append(origin_acc)
        if origin_acc > origin_max_val_acc:
            origin_max_val_acc = origin_acc
            origin_best_k = k

        modified_svd = modified_svd_reconstruct(train_matrix, k=k)
        modified_acc = sparse_matrix_evaluate(val_data, modified_svd)
        modified_valid_acc.append(modified_acc)
        if modified_acc > modified_max_val_acc:
            modified_max_val_acc = modified_acc
            modified_best_k = k

    # Plot the validation accuracy of the original svd algorithm and the
    # modified version for each value of k
    plt.plot(k_values, origin_valid_acc,
             label='Validation Accuracy of the original SVD')
    plt.plot(k_values, modified_valid_acc,
             label='Validation Accuracy of the modified SVD')
    plt.xlabel('K')
    plt.ylabel('Validation Accuracy ')
    plt.title('Validation Accuracy of the original and the modified SVD')
    plt.legend()
    plt.show()


    origin_svd = svd_reconstruct(train_matrix, k=origin_best_k)
    origin_acc = sparse_matrix_evaluate(test_data, origin_svd)
    print("Test Accuracy for the original SVD with its best K value = {}: "
          "{}".format(origin_best_k, origin_acc))
    # Test Accuracy for the original SVD with its best value of K:
    # 0.6587637595258256

    modified_svd = modified_svd_reconstruct(train_matrix, k=modified_best_k)
    modified_acc = sparse_matrix_evaluate(test_data, modified_svd)
    print("Test Accuracy for the modified SVD with its best K value = {}: "
          "{}".format(modified_best_k, modified_acc))
    # Test Accuracy for the modified SVD with its best value of K:
    # 0.6948913350268134

    x = ["original, K=9", "modified, K=3"]
    data = [origin_acc, modified_acc]
    plt.title("Test Accuracy of the original and the modified SVD with its "
              "best K value")
    plt.bar(x, data, width = 0.5)
    plt.grid(ls="--", alpha=0.5)
    plt.text(x[0], data[0], data[0], va="bottom", ha="center", fontsize=10)
    plt.text(x[1], data[1], data[1], va="bottom", ha="center", fontsize=10)
    plt.show()


if __name__ == "__main__":
    main()
