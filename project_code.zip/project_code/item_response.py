from matplotlib import pyplot as plt
from utils import *
import numpy as np


def sigmoid(x):
    """ Apply sigmoid function.
    """
    return np.exp(x) / (1 + np.exp(x))


def neg_log_likelihood(data, theta, beta):
    """ Compute the negative log-likelihood.

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param theta: Vector
    :param beta: Vector
    :return: float
    """
    #####################################################################
    # Implement the function as described in the docstring.             #
    #####################################################################
    log_lklihood = 0.0

    for user_id, question_id, is_correct in zip(data['user_id'],
                                                data['question_id'],
                                                data['is_correct']):
        thetai = theta[user_id]
        betaj = beta[question_id]
        cij = is_correct

        # Compute cij * (thetai - betaj) - log(1 + exp(thetai - betaj))
        l_l_each = cij * (thetai - betaj) - np.log(1 + np.exp(thetai - betaj))
        log_lklihood += l_l_each
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return -log_lklihood


def update_theta_beta(data, lr, theta, beta):
    """ Update theta and beta using gradient descent.

    You are using alternating gradient descent. Your update should look:
    for i in iterations ...
        theta <- new_theta
        beta <- new_beta

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param theta: Vector
    :param beta: Vector
    :return: tuple of vectors
    """
    #####################################################################
    # Implement the function as described in the docstring.             #
    #####################################################################
    # Initialize gradients for theta and beta
    grad_theta = np.zeros_like(theta)
    grad_beta = np.zeros_like(beta)

    # Compute gradient for theta
    for user_id, question_id, is_correct in zip(data['user_id'],
                                                data['question_id'],
                                                data['is_correct']):
        thetai = theta[user_id]
        betaj = beta[question_id]
        cij = is_correct

        x = thetai - betaj

        # Update the gradient for thetai
        exp_term = sigmoid(x)
        grad_theta[user_id] += cij - exp_term

    # Update theta
    theta = theta + lr * grad_theta

    # Compute gradient for beta
    for user_id, question_id, is_correct in zip(data['user_id'],
                                                data['question_id'],
                                                data['is_correct']):
        thetai = theta[user_id]
        betaj = beta[question_id]
        cij = is_correct

        # Update the gradient for betaj
        exp_term = np.exp(thetai - betaj) / (1 + np.exp(thetai - betaj))
        grad_beta[question_id] += -cij + exp_term

    # Update beta
    beta = beta + lr * grad_beta
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return theta, beta


def irt(data, val_data, lr, iterations):
    """ Train IRT model.

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param val_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param iterations: int
    :return: (theta, beta, val_acc_lst)
    """
    #Initialize theta and beta.
    unique_users = np.unique(data['user_id'])
    unique_questions = np.unique(data['question_id'])

    theta = np.zeros(len(unique_users))
    beta = np.zeros(len(unique_questions))

    val_acc_lst = []
    train_lls = []
    val_lls = []

    for i in range(iterations):
        neg_lld = neg_log_likelihood(data, theta=theta, beta=beta)
        score = evaluate(data=val_data, theta=theta, beta=beta)
        val_acc_lst.append(score)
        print("NLLK: {} \t Score: {}".format(neg_lld, score))

        # for plotting training and val log-likelihoods
        train_ll = - neg_lld
        train_lls.append(train_ll)

        val_ll = - neg_log_likelihood(val_data, theta=theta, beta=beta)
        val_lls.append(val_ll)

        theta, beta = update_theta_beta(data, lr, theta, beta)

    return theta, beta, val_acc_lst, train_lls, val_lls


def irt_for_hyper(data, val_data, lr, iterations):
    """ Tune the hyperparameters for IRT model.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param val_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param iterations: int
    :return: (theta, beta, val_acc_lst)
    """
    unique_users = np.unique(data['user_id'])
    unique_questions = np.unique(data['question_id'])

    theta = np.zeros(len(unique_users))
    beta = np.zeros(len(unique_questions))

    max_val_acc = 0
    best_iter = 0

    for i in range(iterations):
        score = evaluate(data=val_data, theta=theta, beta=beta)
        theta, beta = update_theta_beta(data, lr, theta, beta)
        if score > max_val_acc:
            max_val_acc = score
            best_iter = i

    return max_val_acc, best_iter


def evaluate(data, theta, beta):
    """ Evaluate the model given data and return the accuracy.
    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}

    :param theta: Vector
    :param beta: Vector
    :return: float
    """
    pred = []
    for i, q in enumerate(data["question_id"]):
        u = data["user_id"][i]
        x = (theta[u] - beta[q]).sum()
        p_a = sigmoid(x)
        pred.append(p_a >= 0.5)
    return np.sum((data["is_correct"] == np.array(pred))) \
           / len(data["is_correct"])


def main():
    train_data = load_train_csv("../data")
    # You may optionally use the sparse matrix.
    sparse_matrix = load_train_sparse("../data")
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    #####################################################################
    # Tune learning rate and number of iterations. With the implemented #
    # code, report the validation and test accuracy.                    #
    #####################################################################
    # 2(a) Please see our project report.

    # 2(c)
    # Tune the learning rate and number of iterations
    lr_values = [0.005, 0.01, 0.015, 0.02, 0.025, 0.03]
    max_val_acc = 0
    best_combination = (0, 0)
    for lr in lr_values:
        val_acc, best_iter = irt_for_hyper(train_data, val_data, lr, 30)
        if val_acc > max_val_acc:
            max_val_acc = val_acc
            best_combination = lr, best_iter
    print("The best combination of lr and num_iter: " + str(best_combination[0])
          + " and " + str(best_combination[1]))
    print("The validation accuracy with the best combination: " +
          str(max_val_acc))
    # The best combination of lr and num_iter: 0.025 and 5
    # The validation accuracy with the best combination: 0.7095681625740897

    print("----------------------------------------------------------")
    # The hyperparameters we select
    lr = 0.025
    iterations = 5

    # Train the IRT model
    theta, beta, val_acc_lst, train_lls, val_lls = irt(train_data, val_data, lr,
                                                       iterations)

    print("----------------------------------------------------------")
    # Plot the validation accuracy
    plt.plot(val_acc_lst)
    plt.xlabel('Iterations')
    plt.ylabel('Validation Accuracy')
    plt.title('Validation Accuracy over Iterations')
    plt.show()

    print("----------------------------------------------------------")
    # Plot training and validation log-likelihoods as a function of iteration
    plt.plot(train_lls, label='Training Log-Likelihood')
    plt.plot(val_lls, label='Validation Log-Likelihood')
    plt.xlabel('Iteration')
    plt.ylabel('Log-Likelihood')
    plt.title('Training and Validation Log-Likelihoods')
    plt.legend()
    plt.show()

    print("----------------------------------------------------------")
    # Report the validation accuracy
    val_accuracy = evaluate(val_data, theta, beta)
    print(f"Validation Accuracy: {val_accuracy}")
    # Validation Accuracy: 0.7095681625740897

    # Report the test accuracy
    test_accuracy = evaluate(test_data, theta, beta)
    print(f"Test Accuracy: {test_accuracy}")
    # Test Accuracy: 0.7008185153824442
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    #####################################################################
    # Implement part (d)                                                #
    #####################################################################
    # 2(d)
    # For part (d), we select question 1, 2, 3.

    # We have to sort it first in order to avoid the lines crossing each other.
    theta_sorted = np.sort(theta)

    # Select three questions
    p_j1 = sigmoid(theta_sorted - beta[1])
    p_j2 = sigmoid(theta_sorted - beta[2])
    p_j3 = sigmoid(theta_sorted - beta[3])

    # Plot a curve showing the probability of the correct response
    plt.plot(theta_sorted, p_j1, label=f'Question $j_1$ ={beta[1]:.2f})')
    plt.plot(theta_sorted, p_j2, label=f'Question $j_2$ ={beta[2]:.2f})')
    plt.plot(theta_sorted, p_j3, label=f'Question $j_3$ ={beta[3]:.2f})')

    plt.xlabel('Ability $\\theta$')
    plt.ylabel('Probability of Correct Response $p(c_{ij} = 1)$')
    plt.title('Probability of Correct Response as a Function of Ability')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Comment on the shapes of the curves and what these curves represent:
    # The plot indicates that the harder the question is, controlling on
    # student's ability, the smaller probability that the student will answer it
    # correct. Moreover, controlling on the difficulty of the question, student
    # with higher ability will have a greater chance in answer it correct.
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


if __name__ == "__main__":
    main()
